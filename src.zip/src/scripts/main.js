$(document).ready(function () {
	// BANNER SLIDER
	$(".js-banner-slider").on("init", function (event, slick) {
		var $dotList = slick.$dots.find("li");
		var $dotBtn = $dotList.find("button");
		$dotBtn.html("");
		$dotBtn.addClass("p-banner__slider-dot");
		$($dotBtn[0]).addClass("is-active");
	});
	$(".js-banner-slider").on(
		"beforeChange",
		function (event, slick, currentSlide, nextSlide) {
			var $dotList = slick.$dots.find("li");
			var $dotBtn = $dotList.find("button");
			$dotBtn.removeClass("is-active");
			$($dotBtn[nextSlide]).addClass("is-active");
		}
	);
	$(".js-banner-slider").slick({
		dots: true,
		appendDots: $(".js-banner-dots"),
		dotsClass: "slick-dots p-banner__slider-dots",
		nextArrow: $(".js-banner-arrow-next"),
		prevArrow: $(".js-banner-arrow-prev"),
	});
	// END

	// WORK CAROUSEL
	$('.js-work-carousel').slick({
		dots: false,
		infinite: false,
		speed: 300,
		slidesToShow: 4,
		slidesToScroll: 4,
		responsive: [
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2,
					dots: false

				}
			},
			{
				breakpoint: 376,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					dots: false
				}
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		]
	});
	// END
});

